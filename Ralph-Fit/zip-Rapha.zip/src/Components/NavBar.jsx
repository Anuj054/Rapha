
const NavBar = () => {
  return (
    <nav className="bg-customBrown w-full">
      <div className="max-w-full px-0 mx-auto">
        <div className="h-16"></div>
      </div>
    </nav>
  );
};

export default NavBar;
